                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1598033
Recessed Monster Bases (15mm scale) by dutchmogul is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

These bases were designed for standard 15mm scale monster models. Most 15mm scale metal models come with a pesky integrated base that can be difficult to remove. With these bases, just clip away enough of the integrated base to make it fit and glue the model into the recess. This will keep your model flush with the standard 2mm high basing and, with a little flock, you can hide the recess entirely. I've included some rocky rubble bits which help to flavor the base and blend in with what's left of the integrated basing.

We've set up a [Patreon page](https://www.patreon.com/illgottengames) for anyone who's interested in helping to fund us so we can keep making free and open sourced games like Pocket-Tactics, Wayfarer Tactics. and others, not to mention the growing catalog of gaming miniatures that you can use for whatever you want! (Psst... we take requests and commissions...)

Enjoy!

(Models shown are 15mm Hundred Years War soldiers from Corvus Belli and various monsters from [Reaper's Bones](http://www.reapermini.com/) line.)